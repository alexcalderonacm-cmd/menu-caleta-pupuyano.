const CACHE = 'caldeex-mobile-2026-11-v4-mp';
const ASSETS = ['./', './index.html', './manifest.webmanifest', './icon-192.png','./icon-512.png'];
self.addEventListener('install',event=>{
 event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS)));
 self.skipWaiting();
});
self.addEventListener('activate',event=>{
 event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))));
 self.clients.claim();
});
self.addEventListener('fetch',event=>{
 if(event.request.method!=='GET' || new URL(event.request.url).origin!==location.origin || new URL(event.request.url).pathname.startsWith('/.netlify/functions/'))return;
 event.respondWith(fetch(event.request).then(res=>{
  if(res.ok){const clone=res.clone();caches.open(CACHE).then(c=>c.put(event.request,clone));}
  return res;
 }).catch(()=>caches.match(event.request).then(r=>r||caches.match('./index.html'))));
});
