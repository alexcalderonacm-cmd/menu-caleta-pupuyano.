import {cpSync,rmSync,mkdirSync} from 'node:fs';
rmSync('dist',{recursive:true,force:true});
mkdirSync('dist',{recursive:true});
cpSync('site','dist',{recursive:true});
console.log('CALDEEX Web preparada para Netlify');
