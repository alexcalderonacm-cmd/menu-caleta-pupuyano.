import { timingSafeEqual, createHash } from 'node:crypto';

const API = 'https://api.mercadopublico.cl/servicios/v1/publico/';
const states = {'5':'Publicada','6':'Cerrada','7':'Desierta','8':'Adjudicada','18':'Revocada','19':'Suspendida'};
const orderStates = {'4':'Enviada a proveedor','5':'En proceso','6':'Aceptada','9':'Cancelada','12':'Recepción conforme','13':'Pendiente de recepcionar','14':'Recepcionada parcialmente','15':'Recepción conforme incompleta'};
const json = (data, status = 200) => new Response(JSON.stringify(data), {status, headers: {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store, max-age=0','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'}});
const secureEquals = (a,b) => {
  const aa=createHash('sha256').update(a).digest(),bb=createHash('sha256').update(b).digest();
  return timingSafeEqual(aa,bb);
};
const txt = (v,max=300) => typeof v === 'string' ? v.trim().slice(0,max) : '';
const deadline = v => {
  if (!v) return '';
  if (typeof v === 'string' && /^\d{4}-\d{2}-\d{2}/.test(v)) return v.slice(0,10);
  const m=String(v).match(/^\/Date\((\d+)/);
  if (m) return new Date(Number(m[1])).toISOString().slice(0,10);
  return '';
};
export default async (request) => {
  if (request.method !== 'GET') return json({error:'Método no permitido.'},405);
  // Both values must be configured in Netlify > Project configuration > Environment variables.
  const ticket=process.env.CALDEEX_MP_TICKET||'';
  const access=process.env.CALDEEX_MP_CLAVE||'';
  if (!ticket || access.length < 8) return json({error:'Falta configurar el ticket y una clave de consulta de 8 o más caracteres en Netlify.'},503);
  const supplied=request.headers.get('x-caldeex-consulta')||'';
  if (!secureEquals(supplied,access)) return json({error:'Clave de consulta incorrecta.'},401);
  const u=new URL(request.url);
  const codigo=txt(u.searchParams.get('codigo')||'',40).toUpperCase();
  const tipo=u.searchParams.get('tipo')||'licitacion';
  if(!/^[A-Z0-9-]{4,40}$/.test(codigo) || !['licitacion','orden'].includes(tipo)) return json({error:'Tipo o código de consulta inválido.'},400);
  const api=new URL(tipo==='orden'?'ordenesdecompra.json':'licitaciones.json',API);
  api.searchParams.set('codigo',codigo);
  api.searchParams.set('ticket',ticket);
  let upstream;
  try{upstream=await fetch(api,{headers:{'Accept':'application/json'},signal:AbortSignal.timeout(11000)})}
  catch{return json({error:'ChileCompra no respondió a tiempo. Vuelve a intentar.'},504)}
  if(!upstream.ok)return json({error:upstream.status===429?'ChileCompra limitó temporalmente las consultas.':'No fue posible consultar ChileCompra ('+upstream.status+').'},502);
  let payload;
  try{payload=await upstream.json()}catch{return json({error:'La respuesta de ChileCompra no se pudo interpretar.'},502)}
  const first=Array.isArray(payload?.Listado)?payload.Listado[0]:null;
  if (!first) return json({error:'No se encontró información para este ID.'},404);
  const current=String(first.CodigoEstado??'');
  const isOC=tipo==='orden';
  const status= isOC ? (orderStates[current]||txt(first.Estado,100)||'Estado no determinado') : (states[current]||txt(first.Estado,100)||'Estado no determinado');
  const code=txt((isOC?first.Codigo:first.CodigoExterno)||first.Codigo||codigo,40);
  const buyer=first.Comprador||{};
  return json({
    tipo,codigo:code,nombre:txt(first.Nombre,240),organismo:txt(buyer.NombreOrganismo||buyer.NombreUnidad||first.NombreOrganismo,240),
    estado:status,codigoEstado:current,cierre:deadline(first.FechaCierre||first.Fechas?.FechaCierre),
    consultado:new Date().toISOString()
  });
};
